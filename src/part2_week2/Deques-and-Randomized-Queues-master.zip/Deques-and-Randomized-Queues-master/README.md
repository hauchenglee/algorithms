# Deques-and-Randomized-Queues
Assignment 2 of Algorithms MOOC
Second week assignment of coursera mooc "Algorithms. Part I" by R. Sedgewick and K. Wayne https://www.coursera.org/learn/algorithms-part1 

Grade: 100% 

Specification: https://www.coursera.org/learn/algorithms-part1/programming/zamjZ/deques-and-randomized-queues
